
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var survivalTime
var ground
function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
createCanvas(600,600);  
monkey= createSprite(250,324,30,30);
monkey.addAnimation("monkey",monkey_running);  
ground=createSprite(300,390,600,15);  
monkey.scale=0.2;
}


function draw() {
 background("white");
  
  if(keyDown("space")){
  monkey.velocityY=-4;

  }
  monkey.veloctiyY = monkey.velocityY+0.9 ;
  
  FoodGroup();
  obstacleGroup();
  
  monkey.collide(ground);
  if(obstacleGroup.isTouching(monkey)){
    monkey.velocityY=0;
    
obstacleGroup.setVelocityXEach(0);
    FoodGroup.setVelocityXEach(0);
    
obstacleGroup.setLifeTimeEach(-1);
    FoodGroup.setLIfeTimeEach(-1);
  }
  
  stroke("black");
  survivalTime=Math.ceil(frameCount/frameRate())
  text("Survival Time"+survivalTime ,100,50); 
  
  
 
  
  drawSprites();  
}

function FoodGroup(){
  if (frameCount % 80 === 0){
    banana = createSprite(600,200,30,30);
    banana.y=Math.round(random(120,200));
    banana.addImage(bananaImage);
    banana.scale=0.1;
    banana.velocityX=-2;

    banana.lifetime=300;
  }
}

function obstacleGroup(){
  if(frameCount% 300 === 0){
    obstacle= createSprite(600,330,30,30);
    obstacle.addImage(obstacleImage);
    obstacle.scale=0.3;
    obstacle.velocityX=-2;
    obstacle.lifetime=300
    
  }
}





















